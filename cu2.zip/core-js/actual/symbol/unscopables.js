var parent = require('../../stable/symbol/unscopables');

module.exports = parent;
