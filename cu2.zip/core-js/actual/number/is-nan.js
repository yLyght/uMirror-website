var parent = require('../../stable/number/is-nan');

module.exports = parent;
