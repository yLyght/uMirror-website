var parent = require('../../stable/string/bold');

module.exports = parent;
