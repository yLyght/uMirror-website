var parent = require('../../stable/string/includes');

module.exports = parent;
