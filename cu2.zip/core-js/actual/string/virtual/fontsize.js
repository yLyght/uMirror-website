var parent = require('../../../stable/string/virtual/fontsize');

module.exports = parent;
