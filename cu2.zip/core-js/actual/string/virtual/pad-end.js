var parent = require('../../../stable/string/virtual/pad-end');

module.exports = parent;
