var parent = require('../../../stable/string/virtual/bold');

module.exports = parent;
