var parent = require('../../../stable/string/virtual/anchor');

module.exports = parent;
