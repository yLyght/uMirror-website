var parent = require('../../stable/string/blink');

module.exports = parent;
