var parent = require('../../stable/string/trim-start');

module.exports = parent;
