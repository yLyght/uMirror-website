var parent = require('../../stable/string/match-all');

module.exports = parent;
