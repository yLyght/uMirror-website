var parent = require('../../stable/string/at');

module.exports = parent;
