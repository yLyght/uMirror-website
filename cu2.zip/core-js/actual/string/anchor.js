var parent = require('../../stable/string/anchor');

module.exports = parent;
