var parent = require('../../stable/string/fontsize');

module.exports = parent;
