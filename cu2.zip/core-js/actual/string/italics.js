var parent = require('../../stable/string/italics');

module.exports = parent;
