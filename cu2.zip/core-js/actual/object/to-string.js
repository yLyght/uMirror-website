var parent = require('../../stable/object/to-string');

module.exports = parent;
