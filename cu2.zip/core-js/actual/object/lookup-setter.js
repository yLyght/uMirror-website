var parent = require('../../stable/object/lookup-setter');

module.exports = parent;
