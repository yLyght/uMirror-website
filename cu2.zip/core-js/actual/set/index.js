var parent = require('../../stable/set');

module.exports = parent;
