var parent = require('../../stable/dom-exception/to-string-tag');

module.exports = parent;
