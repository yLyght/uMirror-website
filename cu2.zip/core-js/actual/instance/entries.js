var parent = require('../../stable/instance/entries');

module.exports = parent;
