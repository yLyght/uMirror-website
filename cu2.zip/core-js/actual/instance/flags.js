var parent = require('../../stable/instance/flags');

module.exports = parent;
