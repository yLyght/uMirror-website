var parent = require('../../stable/instance/flat');

module.exports = parent;
