var parent = require('../../stable/math/log2');

module.exports = parent;
