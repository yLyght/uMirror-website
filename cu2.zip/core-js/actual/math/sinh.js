var parent = require('../../stable/math/sinh');

module.exports = parent;
