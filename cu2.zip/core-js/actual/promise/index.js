var parent = require('../../stable/promise');

module.exports = parent;
