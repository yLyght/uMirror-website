var parent = require('../../stable/regexp/to-string');

module.exports = parent;
