var parent = require('../../stable/typed-array/to-locale-string');

module.exports = parent;
