var parent = require('../../stable/typed-array/reduce');

module.exports = parent;
