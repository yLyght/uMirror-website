var parent = require('../../stable/typed-array/int8-array');
require('../../actual/typed-array/methods');

module.exports = parent;
