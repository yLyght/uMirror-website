var parent = require('../../stable/typed-array/some');

module.exports = parent;
