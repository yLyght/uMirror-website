var parent = require('../../stable/typed-array/uint32-array');
require('../../actual/typed-array/methods');

module.exports = parent;
