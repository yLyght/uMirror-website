var parent = require('../../stable/url');

module.exports = parent;
