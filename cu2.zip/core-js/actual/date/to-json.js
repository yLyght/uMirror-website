var parent = require('../../stable/date/to-json');

module.exports = parent;
