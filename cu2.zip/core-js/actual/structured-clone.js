var parent = require('../stable/structured-clone');

module.exports = parent;
