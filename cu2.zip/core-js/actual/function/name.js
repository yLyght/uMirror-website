var parent = require('../../stable/function/name');

module.exports = parent;
