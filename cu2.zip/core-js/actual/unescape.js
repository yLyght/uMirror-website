var parent = require('../stable/unescape');

module.exports = parent;
