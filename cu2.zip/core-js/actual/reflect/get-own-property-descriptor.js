var parent = require('../../stable/reflect/get-own-property-descriptor');

module.exports = parent;
