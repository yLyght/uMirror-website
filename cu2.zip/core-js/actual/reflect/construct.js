var parent = require('../../stable/reflect/construct');

module.exports = parent;
