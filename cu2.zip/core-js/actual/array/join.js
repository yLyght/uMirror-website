var parent = require('../../stable/array/join');

module.exports = parent;
