var parent = require('../../stable/array/iterator');

module.exports = parent;
