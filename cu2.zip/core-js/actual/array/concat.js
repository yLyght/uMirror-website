var parent = require('../../stable/array/concat');

module.exports = parent;
