var parent = require('../../../stable/array/virtual/some');

module.exports = parent;
