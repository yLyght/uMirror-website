module.exports = require('../full/aggregate-error');
