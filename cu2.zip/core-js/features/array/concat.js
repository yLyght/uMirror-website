module.exports = require('../../full/array/concat');
