module.exports = require('../../full/array/for-each');
