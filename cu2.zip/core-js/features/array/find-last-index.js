module.exports = require('../../full/array/find-last-index');
