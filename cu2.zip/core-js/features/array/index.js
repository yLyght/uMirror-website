module.exports = require('../../full/array');
