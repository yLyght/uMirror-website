module.exports = require('../../full/array/slice');
