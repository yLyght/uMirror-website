module.exports = require('../../full/array/reduce-right');
