module.exports = require('../../full/array/flat-map');
