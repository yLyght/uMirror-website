module.exports = require('../../full/array/find-index');
