module.exports = require('../../full/array/index-of');
