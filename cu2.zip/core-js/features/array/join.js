module.exports = require('../../full/array/join');
