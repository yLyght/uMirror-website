export default function bigSign(bigIntValue) {
  return (bigIntValue > 0n) - (bigIntValue < 0n)
}
