'use strict';

module.exports = new Map();
