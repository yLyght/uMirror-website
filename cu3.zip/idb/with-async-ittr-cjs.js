module.exports = require('./build/cjs/index.js');
require('./build/cjs/async-iterators.js');
