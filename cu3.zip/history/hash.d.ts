declare const _default: import("history").HashHistory;
/**
 * Create a default instance for the current document.
 */
export default _default;
