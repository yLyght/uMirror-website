declare const _default: import("history").BrowserHistory;
/**
 * Create a default instance for the current document.
 */
export default _default;
