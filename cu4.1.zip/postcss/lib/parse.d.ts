import { Parser } from './postcss.js'

declare const parse: Parser

export default parse
