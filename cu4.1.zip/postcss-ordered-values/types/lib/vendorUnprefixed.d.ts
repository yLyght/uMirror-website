export = vendorUnprefixed;
/**
 * @param {string} prop
 * @return {string}
 */
declare function vendorUnprefixed(prop: string): string;
