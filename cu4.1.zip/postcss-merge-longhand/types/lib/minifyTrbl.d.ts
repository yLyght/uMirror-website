declare const _exports: (v: string | [string, string, string, string]) => string;
export = _exports;
